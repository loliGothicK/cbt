# cbt (Cranberries Build Tool)

Build Tool for C++

# cbt wandbox

'cbt wandbox' command allows to send your C++ codes to wandbox.

```cpp
// hello.cpp
#include <iostream>

int main(){
  std::cout << "Hello cbt!" << std::endl;
}
```

```
$ cbt wandbox hello.cpp
hello cbt!
```
